#!/bin/bash
haasInstance=HAASAAD0141_02121
yarn_queueName=NONP.HAASAAD0141_02121

#login to functional account(No Change Required in below kinit command)
keytabUserName=$2
tgt_path=$1
kinit -kt ${tgt_path}/Scripts/${keytabUserName}.keytab ${keytabUserName}@IUSER.IROOT.ADIDOM.COM

#Rollback Steps to be written from here
beeline --showHeader=false --outputformat=csv2 --hiveconf mapreduce.job.queuename=$yarn_queueName -u 'jdbc:hive2://tplhc01c002:10000/'"$haasInstance"';principal=hive/tplhc01c002.iuser.iroot.adidom.com@IUSER.IROOT.ADIDOM.COM' -e "drop table test_devops"
