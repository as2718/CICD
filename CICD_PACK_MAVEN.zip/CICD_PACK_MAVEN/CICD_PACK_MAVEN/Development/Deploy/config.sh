[ENV]
   HOSTNAME=haas1a-gw1-prod.nat.bt.com
   FORWARD_SCRIPT=forward.sh
   ROLLBACK_SCRIPT=rollback.sh
   JENKINS_KEYTAB_ID=CAD_ACCT
[MAVEN]
   
   POM_FILE_PATH=Project/myapp

[ANSIBLE]
   ANSIBLE_SSH_ID=ANSIBLE_SSH_ID
[NEXUS]
   APPLICATION_NAME=MI_KITCHEN
   REPOSITORY_NAME=BDNGBL_Big-Data-COE---Global_maven_releases
   NEXUS_CRED=NEXUS_CRED
   ROLLBACK_REPOSITORY_NAME=BDNGBL_Big-Data-COE---Global_maven_releases

   ROLLBACK_GROUP_ID=MI_KITCHEN
   ROLLBACK_ARTIFACT_ID=mi_kitchen_2.10

   ROLLBACK_VERSION_NO=0.2

[MAIL]
   TO=abhishek.2.srivastav@bt.com;binjith.balakrishnan@bt.com