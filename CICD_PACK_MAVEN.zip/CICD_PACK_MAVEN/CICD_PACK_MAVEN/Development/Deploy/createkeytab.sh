#!/bin/sh
user=$1
pass=$2
tgt=$3

printf "%b" "addent -password -p $user -k 1 -e rc4-hmac\n$pass\nwkt $tgt/Scripts/$user.keytab" | ktutil
printf "%b" "read_kt  $tgt/Scripts/$user.keytab\nlist" | ktutil